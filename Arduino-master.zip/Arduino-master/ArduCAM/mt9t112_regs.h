#ifndef MT9M112_REGS_H
#define MT9M112_REGS_H
#include "ArduCAM.h"
#include <Wire.h>

const struct sensor_reg MT9T112_QVGA[] PROGMEM=
{
	


	{0xffff, 0xffff},
};

#endif

